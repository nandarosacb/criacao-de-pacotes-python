# meu_pacote/__init__.py

from .file1_name import carregar_imagem
from .file2_name import combinar_imagens
